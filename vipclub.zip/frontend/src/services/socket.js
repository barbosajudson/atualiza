export function socketConnection(params) {
  throw new Error("Favor usar o SocketContext");
}
